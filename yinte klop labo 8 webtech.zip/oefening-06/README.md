# 💻 08. API's uitlezen > oefening 06

## 🛠️ opdrachten

Tijdens dit labo leer je
 - gebruik maken van een authentication token.

### Postman opstarten

 - Start Postman.

### authentificatie met token

 - [API: Auth0 Management API](https://auth0.com/docs/api/management/v2)
 - endpoint: /users

---

1. Maak een nieuw verzoek naar de API.
2. Gebruik de endpoint /users.
3. Voeg een Authorization header toe met een Bearer Token.
4. Voer het verzoek uit en bekijk de lijst met gebruikers.


nie werk nie wtf is deze shit