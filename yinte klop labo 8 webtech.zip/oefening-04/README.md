# 💻 08. API's uitlezen > oefening 04

## 🛠️ opdrachten

### Postman opstarten

 - Start Postman.

### endpoints opzoeken

 - Ga op zoek naar een geschikte API die in lijn ligt van jouw topic voor jouw langlopende taak.
 - Zoek minstens 3 endpoints op van de API.

Allemaal proprietary-bureaucratie-fuckinghell brol